/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"ppmtoxml - Convert a Portable PixMap (PPM) image to an XML representation.\n",
"ppmtoxml --help\n",
"ppmtoxml [-name iname] [name]\n",
"ppmtoxml -alpha alpha [-name iname] [name]\n",

NULL};
