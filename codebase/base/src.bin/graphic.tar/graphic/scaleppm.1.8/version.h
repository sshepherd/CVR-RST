/*version.h
  =========*/

 #define MAJOR_VERSION "1"
 #define MINOR_VERSION "8"
