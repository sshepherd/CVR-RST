/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"scaleppm - Scale a Portable PixMap (PPM) image.\n",
"scaleppm --help\n",
"scaleppm [-smooth] [-wdt width] [-hgt height] [name]\n",
"scaleppm [-smooth] [-sf scale] [name]\n",

NULL};
