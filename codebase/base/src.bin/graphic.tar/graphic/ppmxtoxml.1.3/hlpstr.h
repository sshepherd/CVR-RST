/* hlpstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *hlpstr[]={
"ppmxtoxml - Convert an extended Portable PixMap (PPMX) image to an XML representation.\n",
"ppmxtoxml --help\n",
"ppmxtoxml [name]\n",

"--help\tprint the help message and exit.\n",
"name\tinput image filename. If this is omitted the image  will be read from standard input.\n",

NULL};
