/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"ppmxtoxml - Convert an extended Portable PixMap (PPMX) image to an XML representation.\n",
"ppmxtoxml --help\n",
"ppmxtoxml [name]\n",

NULL};
