/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"scaleppmx - Scale an extended Portable PixMap (PPMX) image.\n",
"scaleppmx --help\n",
"scaleppmx [-smooth] [-wdt width] [-hgt height] [name]\n",

NULL};
