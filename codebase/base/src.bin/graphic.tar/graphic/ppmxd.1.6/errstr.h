/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"ppmxd - Displays an extended Portable PixMap (PPMX) on an X-terminal.\n",
"ppmxd --help\n",
"ppmxd [-smooth] [-scale sf] [-check] [-bgcol rrggbb] [-display display] [-xoff xoff] [-yoff yoff] [name]\n",

NULL};
