/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"scalexml - Scale an XML representation of an image.\n",
"scalexml --help\n",
"scalexml [-smooth] [-wdt width] [-hgt height] [name]\n",

NULL};
