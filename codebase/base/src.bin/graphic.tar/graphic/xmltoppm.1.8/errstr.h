/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"xmltoppm - Convert an XML image representation to a Portable PixMap (PPM).\n",
"xmltoppm --help\n",
"xmltoppm [-bgcol rrggbb] [name]\n",

NULL};
