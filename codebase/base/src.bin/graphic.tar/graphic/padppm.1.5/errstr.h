/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"padppm - Pad the edges of a Portable PixMap (PPM) image.\n",
"padppm --help\n",
"padppm [-wdt width] [-hgt height] [-xpad xpad] [-ypad ypad] [-bgcol rrggbb] [name]\n",

NULL};
