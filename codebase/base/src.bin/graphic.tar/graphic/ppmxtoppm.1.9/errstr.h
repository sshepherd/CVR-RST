/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"ppmxtoppm - Convert an extended Portable PixMap (PPMX) image to Portable PixMap (PPM).\n",
"ppmxtoppm --help\n",
"ppmxtoppm [-bgcol rrggbb] [-a alphaname] [name]\n",

NULL};
