/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"xmld - Displays an XML image representation on an X-terminal.\n",
"xmld --help\n",
"xmld [-smooth] [-scale sf] [-check] [-bgcol rrggbb] [-display display] [-xoff xoff] [-yoff yoff] [name]\n",

NULL};
