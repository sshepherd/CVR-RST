/* hlpstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *hlpstr[]={
"xmltoppmx - Convert an XML image representation to an extended Portable PixMap (PPMX) image.\n",
"xmltoppmx --help\n",
"xmltoppmx [name]\n",

"--help\tprint the help message and exit.\n",
"name\tinput image filename. If this is omitted the image  will be read from standard input.\n",

NULL};
