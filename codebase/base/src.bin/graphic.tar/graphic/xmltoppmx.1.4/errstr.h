/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"xmltoppmx - Convert an XML image representation to an extended Portable PixMap (PPMX) image.\n",
"xmltoppmx --help\n",
"xmltoppmx [name]\n",

NULL};
