/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"ppmd - Displays an extended Portable PixMap (PPMX) on an X-terminal.\n",
"ppmd --help\n",
"ppmd [-smooth] [-scale sf] [-wdt width] [-hgt height] [-display display] [-xoff xoff] [-yoff yoff] [name]\n",

NULL};
