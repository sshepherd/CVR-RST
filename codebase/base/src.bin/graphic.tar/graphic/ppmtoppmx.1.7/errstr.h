/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"ppmtoppmx - Convert a Portable PixMap (PPM) image to an extended Portable PixMap (PPMX) image.\n",
"ppmtoppmx --help\n",
"ppmtoppmx [-name iname] [name]\n",
"ppmtoppmx -alpha alpha [-name iname] [name]\n",
"ppmtoppmx -nz [-name iname] [name]\n",

NULL};
